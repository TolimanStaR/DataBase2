create function edit_popularity() returns trigger
    language plpgsql
as
$$
DECLARE
    line library%rowtype;
	usage_line integer;
	usage_book_id integer;
	user_usage double precision := 0;
	total_usage double precision := 0;
BEGIN
	
	FOR usage_line IN
		SELECT book_id FROM usage
		LOOP
			total_usage = total_usage + 1;
		END LOOP;
	
    FOR line IN
        SELECT * FROM library
        LOOP
			user_usage = 0;
			FOR usage_book_id IN
				SELECT book_id FROM usage WHERE book_id = line.book_id
				LOOP
				
				user_usage = user_usage + 1;
				
				END LOOP;
		
			UPDATE library
			SET popularity = user_usage / total_usage WHERE library.id = line.id;
-- 			SUM (1) FROM usage  WHERE library.id = line.id;
-- 			line.popularity = 10;
-- 			UPDATE library
-- 			SET popularity = 10
--             line.popularity = SELECT count( * )  FROM usage; --WHERE book_id = line.book_id;
--                                   / count(SELECT * FROM usage);
--             RETURN NEXT;
        END LOOP;
    RETURN NEW;
END;
$$;

alter function edit_popularity() owner to postgres;

